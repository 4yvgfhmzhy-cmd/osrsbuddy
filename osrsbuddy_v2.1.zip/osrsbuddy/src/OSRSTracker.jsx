
import { useState, useEffect, useCallback, useRef } from "react";
import Anthropic from "@anthropic-ai/sdk";

// ── OSRS skill list (index matches hiscores CSV row order) ──
const SKILLS = [
  { name: "Overall",      icon: "⚔️" },
  { name: "Attack",       icon: "⚔️" },
  { name: "Defence",      icon: "🛡️" },
  { name: "Strength",     icon: "💪" },
  { name: "Hitpoints",    icon: "❤️" },
  { name: "Ranged",       icon: "🏹" },
  { name: "Prayer",       icon: "🙏" },
  { name: "Magic",        icon: "🔮" },
  { name: "Cooking",      icon: "🍖" },
  { name: "Woodcutting",  icon: "🪓" },
  { name: "Fletching",    icon: "🪶" },
  { name: "Fishing",      icon: "🎣" },
  { name: "Firemaking",   icon: "🔥" },
  { name: "Crafting",     icon: "✂️" },
  { name: "Smithing",     icon: "⚒️" },
  { name: "Mining",       icon: "⛏️" },
  { name: "Herblore",     icon: "🌿" },
  { name: "Agility",      icon: "🏃" },
  { name: "Thieving",     icon: "🗝️" },
  { name: "Slayer",       icon: "💀" },
  { name: "Farming",      icon: "🌾" },
  { name: "Runecrafting", icon: "🔵" },
  { name: "Hunter",       icon: "🦊" },
  { name: "Construction", icon: "🏠" },
];

const XP_TABLE = [0,83,174,276,388,512,650,801,969,1154,1358,1584,1833,2107,2411,2746,3115,3523,3973,4470,5018,5624,6291,7028,7842,8740,9730,10824,12031,13363,14833,16456,18247,20224,22406,24815,27473,30408,33648,37224,41171,45529,50339,55649,61512,67983,75127,83014,91721,101333,111945,123660,136594,150872,166636,184040,203254,224466,247886,273742,302288,333804,368599,407015,449428,496254,547953,605032,667991,737627,814445,899257,992895,1096278,1210421,1336443,1475581,1629200,1798808,1986068,2192818,2421087,2673114,2951373,3258594,3597792,3972294,4385776,4842295,5346332,5902831,6517253,7195629,7944614,8771558,9684577,10692629,13034431];

// Returns 1–99; virtual levels beyond 99 are intentionally clamped.
function xpToLevel(xp) {
  for (let i = XP_TABLE.length - 1; i >= 0; i--) {
    if (xp >= XP_TABLE[i]) return Math.min(i + 1, 99);
  }
  return 1;
}

function xpForLevel(lvl) { return XP_TABLE[Math.min(lvl - 1, 98)] || 0; }

function xpProgress(xp) {
  const lvl = xpToLevel(xp);
  if (lvl >= 99) return 1;
  const curr = xp - xpForLevel(lvl);
  const needed = xpForLevel(lvl + 1) - xpForLevel(lvl);
  return curr / needed;
}

// Fix #13: fmt with cleaner k/m formatting
function fmt(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, "") + "m";
  if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, "") + "k";
  return n.toString();
}

// Hardcoded snapshot for Legaet-Plix (fallback)
const SNAPSHOT = {
  username: "Legaet-Plix",
  skills: {
    Overall: { level: 421, xp: 1604000 },
    Attack: { level: 61, xp: 357000 },
    Defence: { level: 60, xp: 273000 },
    Strength: { level: 63, xp: 411000 },
    Hitpoints: { level: 62, xp: 384000 },
    Ranged: { level: 1, xp: 0 },
    Prayer: { level: 28, xp: 11000 },
    Magic: { level: 29, xp: 14000 },
    Cooking: { level: 1, xp: 0 },
    Woodcutting: { level: 1, xp: 0 },
    Fletching: { level: 1, xp: 0 },
    Fishing: { level: 1, xp: 0 },
    Firemaking: { level: 1, xp: 0 },
    Crafting: { level: 58, xp: 245000 },
    Smithing: { level: 1, xp: 0 },
    Mining: { level: 1, xp: 0 },
    Herblore: { level: 1, xp: 0 },
    Agility: { level: 1, xp: 0 },
    Thieving: { level: 1, xp: 0 },
    Slayer: { level: 33, xp: 20000 },
    Farming: { level: 1, xp: 0 },
    Runecrafting: { level: 1, xp: 0 },
    Hunter: { level: 1, xp: 0 },
    Construction: { level: 1, xp: 0 },
  }
};

const QUESTS_LEGACY = [
  { name: "Priest in Peril", category: "Morytania Access", reqs: { Prayer: 0 }, desc: "Unlocks Morytania, needed for Barrows.", reward: "1406 Prayer XP, Morytania access", priority: "high" },
  { name: "Animal Magnetism", category: "Ranged", reqs: { Ranged: 30, Slayer: 18, Crafting: 35 }, desc: "Unlocks Ava's Accumulator (ammo return).", reward: "Ava's Accumulator", priority: "high" },
  { name: "Horror from the Deep", category: "Magic", reqs: { Agility: 35 }, desc: "Unlocks god books — great offensive bonuses.", reward: "4662 Magic XP, God books", priority: "medium" },
  { name: "Witch's House", category: "Hitpoints", reqs: {}, desc: "Fast free Hitpoints XP early game.", reward: "6325 HP XP", priority: "low" },
  { name: "Imp Catcher", category: "Magic", reqs: {}, desc: "Free Magic XP from beads (buy on GE).", reward: "875 Magic XP, Amulet of accuracy", priority: "high" },
  { name: "Dragon Slayer I", category: "Defence", reqs: { Defence: 0 }, desc: "Unlocks rune platebody, one of the strongest F2P achievements.", reward: "18650 Strength/Defence/HP XP", priority: "high" },
  { name: "Lost City", category: "Combat", reqs: { Crafting: 31, Woodcutting: 36 }, desc: "Unlocks Dragon Longsword/Dagger + Zanaris.", reward: "Dragon weapons access", priority: "medium" },
  { name: "The Grand Tree", category: "Agility", reqs: { Agility: 25 }, desc: "Gives 18400 Agility XP — great early boost.", reward: "18400 Agility XP", priority: "medium" },
  { name: "Fremennik Trials", category: "Crafting", reqs: { Crafting: 40, Fletching: 25, Woodcutting: 40 }, desc: "Access to Neitiznot and Dagannoth Kings region.", reward: "Helm of Neitiznot path", priority: "medium" },
  { name: "Lunar Diplomacy", category: "Magic", reqs: { Crafting: 61, Firemaking: 49, Woodcutting: 55, Magic: 65, Defence: 65 }, desc: "Unlocks the Lunar spellbook.", reward: "Lunar spellbook", priority: "low" },
];

const BOSSES_LEGACY = [
  { name: "Giant Mole", reqs: {}, desc: "Below Falador Park. Drops mole skins for bird nests.", status: "ready" },
  { name: "King Black Dragon", reqs: { Ranged: 70 }, desc: "Need anti-dragon shield and 70 Ranged.", status: "ranged" },
  { name: "Barrows", reqs: { Prayer: 43, Magic: 70 }, desc: "Need 43 Prayer + 70 Magic + Priest in Peril.", status: "prayer_magic" },
  { name: "God Wars (entry)", reqs: { Attack: 70, Strength: 70, Defence: 70 }, desc: "Need 70 combat stats and ideally 70 Prayer.", status: "stats" },
  { name: "Kalphite Queen", reqs: { Ranged: 70, Prayer: 43 }, desc: "High melee + range + 43 Prayer needed.", status: "ranged_prayer" },
  { name: "Dagannoth Kings", reqs: { Attack: 70, Ranged: 70, Magic: 70 }, desc: "Need 70 in all three combat styles.", status: "all_combat" },
  { name: "Vorkath", reqs: { Attack: 70, Ranged: 70, Magic: 70, Defence: 70 }, desc: "Requires Dragon Slayer II completion.", status: "long_term" },
];

const MILESTONES = [
  { skill: "Attack",   target: 70, label: "Abyssal Whip (BiS melee)", color: "#c0392b" },
  { skill: "Strength", target: 70, label: "Major DPS + quest unlock",  color: "#e67e22" },
  { skill: "Defence",  target: 70, label: "Barrows armour sets",        color: "#2980b9" },
  { skill: "Prayer",   target: 43, label: "Protect from Melee",         color: "#8e44ad" },
  { skill: "Ranged",   target: 70, label: "Blowpipe + mid-game bossing",color: "#27ae60" },
  { skill: "Magic",    target: 55, label: "High Alchemy (passive GP)",  color: "#16a085" },
  { skill: "Slayer",   target: 50, label: "More profitable tasks",       color: "#d35400" },
  { skill: "Agility",  target: 30, label: "Falador Rooftop run regen",  color: "#7f8c8d" },
];

const BANK_ITEMS_LEGACY = [
  { name: "Rune scimitar",    qty: 1,   id: 1333 },
  { name: "Dragon bones",     qty: 40,  id: 536  },
  { name: "Rune platebody",   qty: 1,   id: 1127 },
  { name: "Nature rune",      qty: 200, id: 561  },
  { name: "Shark",            qty: 50,  id: 385  },
  { name: "Prayer potion(4)", qty: 10,  id: 2434 },
  { name: "Grimy ranarr",     qty: 30,  id: 207  },
  { name: "Adamant platebody",qty: 2,   id: 1123 },
  { name: "Magic logs",       qty: 100, id: 1513 },
  { name: "Coal",             qty: 500, id: 453  },
  { name: "Gold ore",         qty: 200, id: 444  },
  { name: "Yew logs",         qty: 150, id: 1515 },
];

// Fix #15: moved outside component so it never re-allocates on keystroke
const LB_ROWS = [
  "Lynx Titan — Cmb 126", "Zezima — Cmb 126", "B0aty — Cmb 126", "Swampletics — Cmb 87",
  "Settled — Cmb 96", "Woox — Cmb 126", "Framed — Cmb 105", "Alkan — Cmb 126",
  "Mmorpg — Cmb 126", "J1mmy — Cmb 126", "Didiking — Cmb 126", "Torvesta — Cmb 90",
];

// Fix #14: Google Fonts moved to document <head>. Insert once on module load.
if (typeof document !== "undefined" && !document.getElementById("osrs-fonts")) {
  const link = document.createElement("link");
  link.id = "osrs-fonts";
  link.rel = "stylesheet";
  link.href = "https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap";
  document.head.appendChild(link);
}


// ─────────────────────────────────────────────
// FEATURE 1 — XP TRACKER (gains since session start)
// ─────────────────────────────────────────────
function useXpTracker(skills) {
  const baselineRef = useRef(null);
  const [gains, setGains] = useState({});

  useEffect(() => {
    if (!baselineRef.current && Object.keys(skills).length > 0) {
      baselineRef.current = skills;
    }
  }, [skills]);

  useEffect(() => {
    if (!baselineRef.current) return;
    const newGains = {};
    for (const [skill, data] of Object.entries(skills)) {
      if (skill === "Overall") continue;
      const baseline = baselineRef.current[skill]?.xp || 0;
      const gained = (data.xp || 0) - baseline;
      if (gained > 0) newGains[skill] = gained;
    }
    setGains(newGains);
  }, [skills]);

  function resetBaseline() { baselineRef.current = skills; setGains({}); }
  return { gains, resetBaseline };
}

function XpTrackerTab({ skills, gains, resetBaseline }) {
  const entries = Object.entries(gains).sort((a, b) => b[1] - a[1]);
  const totalGained = entries.reduce((s, [, v]) => s + v, 0);
  return (
    <div>
      <div className="section-title">XP Gains This Session</div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ fontSize: 13, color: "var(--muted)" }}>
          {entries.length === 0 ? "No gains recorded yet — refresh stats after training." : `${entries.length} skill${entries.length !== 1 ? "s" : ""} trained · ${fmt(totalGained)} total XP`}
        </div>
        <button className="btn" onClick={resetBaseline}>↺ Reset baseline</button>
      </div>
      {entries.length === 0 ? (
        <div style={{ background: "var(--parch)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: 20, textAlign: "center", color: "var(--muted)", fontSize: 13 }}>
          Train a skill, then hit <strong style={{ color: "var(--gold)" }}>↻ Refresh</strong> in the header to see gains appear here.
        </div>
      ) : entries.map(([skill, xpGain]) => {
        const sk = SKILLS.find(s => s.name === skill);
        const before = baselineRef.current?.[skill]?.xp || 0; // eslint-disable-line
        const after  = skills[skill]?.xp || 0;
        const lvlBefore = xpToLevel(before);
        const lvlAfter  = xpToLevel(after);
        const levelled  = lvlAfter > lvlBefore;
        return (
          <div key={skill} style={{ background: "var(--parch)", border: `1px solid ${levelled ? "#2d6a2d" : "var(--border)"}`, borderRadius: "var(--radius)", padding: "10px 14px", marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 18 }}>{sk?.icon}</span>
              <div>
                <div style={{ fontSize: 13, color: "var(--text)", fontWeight: 500 }}>{skill}</div>
                {levelled && <div style={{ fontSize: 10, color: "#6bff6b" }}>🎉 Level up! {lvlBefore} → {lvlAfter}</div>}
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "'Cinzel', serif", fontSize: 16, color: "var(--gold2)" }}>+{fmt(xpGain)} xp</div>
              <div style={{ fontSize: 10, color: "var(--muted)" }}>Lv {lvlAfter}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────
// FEATURE 2 — EXPANDED QUESTS & BOSSES
// ─────────────────────────────────────────────
const QUESTS_FULL = [
  // Original 10
  { name: "Priest in Peril",       category: "Morytania Access", reqs: {},                                          desc: "Unlocks Morytania, needed for Barrows.",                   reward: "1406 Prayer XP, Morytania access",   priority: "high"   },
  { name: "Animal Magnetism",      category: "Ranged",           reqs: { Ranged: 30, Slayer: 18, Crafting: 35 },    desc: "Unlocks Ava's Accumulator (ammo return).",               reward: "Ava's Accumulator",                  priority: "high"   },
  { name: "Horror from the Deep",  category: "Magic",            reqs: { Agility: 35 },                             desc: "Unlocks god books — great offensive bonuses.",            reward: "4662 Magic XP, God books",            priority: "medium" },
  { name: "Witch's House",         category: "Hitpoints",        reqs: {},                                          desc: "Fast free Hitpoints XP early game.",                      reward: "6325 HP XP",                          priority: "low"    },
  { name: "Imp Catcher",           category: "Magic",            reqs: {},                                          desc: "Free Magic XP from beads (buy on GE).",                  reward: "875 Magic XP, Amulet of accuracy",   priority: "high"   },
  { name: "Dragon Slayer I",       category: "Defence",          reqs: {},                                          desc: "Unlocks rune platebody, F2P pinnacle.",                   reward: "18650 Str/Def/HP XP",                 priority: "high"   },
  { name: "Lost City",             category: "Combat",           reqs: { Crafting: 31, Woodcutting: 36 },           desc: "Unlocks Dragon Longsword/Dagger + Zanaris.",              reward: "Dragon weapons access",               priority: "medium" },
  { name: "The Grand Tree",        category: "Agility",          reqs: { Agility: 25 },                             desc: "Gives 18400 Agility XP — great early boost.",            reward: "18400 Agility XP",                    priority: "medium" },
  { name: "Fremennik Trials",      category: "Crafting",         reqs: { Crafting: 40, Fletching: 25, Woodcutting: 40 }, desc: "Access to Neitiznot + Dagannoth Kings region.",     reward: "Helm of Neitiznot path",              priority: "medium" },
  { name: "Lunar Diplomacy",       category: "Magic",            reqs: { Crafting: 61, Firemaking: 49, Woodcutting: 55, Magic: 65, Defence: 65 }, desc: "Unlocks the Lunar spellbook.", reward: "Lunar spellbook",                priority: "low"    },
  // New quests
  { name: "Waterfall Quest",       category: "Combat XP",        reqs: {},                                          desc: "Best early quest XP dump — no skill reqs at all.",       reward: "13750 Att + 13750 Str XP",            priority: "high"   },
  { name: "Fight Arena",           category: "Combat XP",        reqs: {},                                          desc: "Free combat XP, no requirements.",                       reward: "12175 Att XP, 2175 Slayer XP",        priority: "high"   },
  { name: "Tree Gnome Village",    category: "Combat XP",        reqs: {},                                          desc: "Quick quest, decent XP reward.",                         reward: "11450 Str XP",                        priority: "high"   },
  { name: "Vampire Slayer",        category: "Combat XP",        reqs: {},                                          desc: "Short quest, good Attack XP.",                           reward: "4825 Attack XP",                      priority: "medium" },
  { name: "Merlin's Crystal",      category: "Camelot",          reqs: {},                                          desc: "Unlocks Camelot teleport destination.",                   reward: "Camelot access",                      priority: "medium" },
  { name: "Holy Grail",            category: "Prayer",           reqs: { Attack: 20 },                              desc: "Good Prayer XP, requires Merlin's Crystal.",             reward: "11000 Prayer XP",                     priority: "medium" },
  { name: "Nature Spirit",         category: "Morytania",        reqs: { Crafting: 18 },                            desc: "Unlocks Mort Myre swamp, needed for some Slayer tasks.", reward: "3000 Crafting XP, ghost speak",       priority: "medium" },
  { name: "Biohazard",             category: "Magic",            reqs: {},                                          desc: "Required for Mourning's End — part of elf quest chain.", reward: "1250 Magic XP",                       priority: "low"    },
  { name: "Death Plateau",         category: "Agility",          reqs: {},                                          desc: "Required for Troll Stronghold + Slayer tasks.",          reward: "Climbing boots",                      priority: "medium" },
  { name: "Troll Stronghold",      category: "Agility",          reqs: { Agility: 15 },                             desc: "Unlocks god armour (Proselyte path).",                   reward: "10000+ Agility XP",                   priority: "medium" },
  { name: "Underground Pass",      category: "Agility",          reqs: { Agility: 25, Ranged: 25 },                 desc: "Required to progress elf quest chain.",                  reward: "3000 Agility XP",                     priority: "low"    },
  { name: "Haunted Mine",          category: "Slayer",           reqs: { Agility: 15, Strength: 35 },               desc: "Unlocks Salve Amulet — essential for undead Slayer.",    reward: "Salve Amulet",                        priority: "high"   },
  { name: "Slayer (Smoking Kills)","category": "Slayer",         reqs: { Slayer: 35 },                              desc: "Doubles Slayer points — do this ASAP.",                  reward: "2x Slayer points forever",            priority: "high"   },
  { name: "Cabin Fever",           category: "Ranged",           reqs: { Agility: 42, Crafting: 45, Smithing: 50, Ranged: 40 }, desc: "Unlocks Ava's Assembler upgrade path.", reward: "Ava's Attractor upgrade access",     priority: "medium" },
  { name: "Dragon Slayer II",      category: "Endgame",          reqs: { Magic: 75, Smithing: 70, Mining: 68, Agility: 62, Thieving: 60, Construction: 60, Hitpoints: 50 }, desc: "Unlocks Vorkath + Dragonfire Ward.", reward: "Vorkath, Dragonfire Ward", priority: "low" },
];

const BOSSES_FULL = [
  { name: "Giant Mole",         reqs: {},                                            desc: "Below Falador Park. Drops mole skins for bird nests."             },
  { name: "Bryophyta",          reqs: { Attack: 40, Strength: 40 },                  desc: "Moss Giant boss variant. Drops mossy key for access."             },
  { name: "Obor",               reqs: { Attack: 40, Strength: 40 },                  desc: "Hill Giant boss. Requires giant key from Hill Giants."            },
  { name: "Barrows",            reqs: { Prayer: 43, Magic: 70 },                     desc: "Need 43 Prayer + 70 Magic + Priest in Peril quest."               },
  { name: "Sarachnis",          reqs: { Attack: 60, Strength: 60, Defence: 60 },     desc: "Mid-game boss in Forthos Dungeon. Good GP/hr."                    },
  { name: "King Black Dragon",  reqs: { Ranged: 70 },                                desc: "Anti-dragon shield essential. Great early Ranged boss."           },
  { name: "Kalphite Queen",     reqs: { Ranged: 70, Prayer: 43 },                    desc: "High melee + Ranged + 43 Prayer needed."                         },
  { name: "Venenatis",          reqs: { Ranged: 70, Prayer: 43 },                    desc: "Wilderness spider boss. High Prayer + Ranged recommended."        },
  { name: "Callisto",           reqs: { Attack: 60, Strength: 60, Prayer: 43 },      desc: "Wilderness bear boss. Melee focused, decent drops."               },
  { name: "Zulrah",             reqs: { Ranged: 70, Magic: 70 },                     desc: "Snake boss, need both Ranged + Magic. Top-tier GP/hr."            },
  { name: "God Wars (entry)",   reqs: { Attack: 70, Strength: 70, Defence: 70 },     desc: "Need 70 combat stats and ideally 70 Prayer for protection."       },
  { name: "Corporeal Beast",    reqs: { Attack: 70, Strength: 70, Defence: 70, Prayer: 70 }, desc: "Requires high stats + specs from Corp-specific weapons."  },
  { name: "Dagannoth Kings",    reqs: { Attack: 70, Ranged: 70, Magic: 70 },         desc: "Three kings — need all three combat styles at 70."               },
  { name: "Vorkath",            reqs: { Attack: 70, Ranged: 70, Magic: 70, Defence: 70 }, desc: "Requires Dragon Slayer II. Blowpipe + Void recommended."     },
  { name: "Theatre of Blood",   reqs: { Attack: 80, Strength: 80, Defence: 80, Ranged: 80, Magic: 80 }, desc: "End-game raid. Full BiS team content."       },
];

// ─────────────────────────────────────────────
// FEATURE 3 — EDITABLE BANK TAB
// ─────────────────────────────────────────────
const DEFAULT_BANK = [
  { name: "Rune scimitar",     qty: 1,   id: 1333 },
  { name: "Dragon bones",      qty: 40,  id: 536  },
  { name: "Rune platebody",    qty: 1,   id: 1127 },
  { name: "Nature rune",       qty: 200, id: 561  },
  { name: "Shark",             qty: 50,  id: 385  },
  { name: "Prayer potion(4)",  qty: 10,  id: 2434 },
  { name: "Grimy ranarr",      qty: 30,  id: 207  },
  { name: "Adamant platebody", qty: 2,   id: 1123 },
  { name: "Magic logs",        qty: 100, id: 1513 },
  { name: "Coal",              qty: 500, id: 453  },
  { name: "Gold ore",          qty: 200, id: 444  },
  { name: "Yew logs",          qty: 150, id: 1515 },
];

function useBankItems() {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem("osrs_bank")) || DEFAULT_BANK; } catch { return DEFAULT_BANK; }
  });
  function save(next) { setItems(next); localStorage.setItem("osrs_bank", JSON.stringify(next)); }
  function updateQty(id, qty) { save(items.map(i => i.id === id ? { ...i, qty: Math.max(0, qty) } : i).filter(i => i.qty > 0)); }
  function removeItem(id) { save(items.filter(i => i.id !== id)); }
  function addItem(item) { save([...items, item]); }
  return { items, updateQty, removeItem, addItem };
}

function BankTabV2() {
  const { items, updateQty, removeItem, addItem } = useBankItems();
  const [prices, setPrices] = useState({});
  const [priceStatus, setPriceStatus] = useState("loading");
  const [adding, setAdding] = useState(false);
  const [newName, setNewName] = useState(""); const [newQty, setNewQty] = useState(1); const [newId, setNewId] = useState("");

  useEffect(() => {
    async function fetchPrices() {
      const ids = items.map(i => i.id);
      try {
        const res = await fetch(`https://prices.runescape.wiki/api/v1/latest?id=${ids.join(",")}`, { headers: { "User-Agent": "OSRSBuddy" } });
        if (!res.ok) throw new Error();
        const json = await res.json();
        const live = {};
        for (const [id, d] of Object.entries(json.data || {})) {
          const h = d.high || 0; const l = d.low || 0;
          live[parseInt(id)] = h && l ? Math.round((h + l) / 2) : h || l;
        }
        setPrices(live); setPriceStatus("live");
      } catch { setPriceStatus("offline"); }
    }
    fetchPrices();
  }, [items.map(i => i.id).join(",")]);

  const total = items.reduce((s, i) => s + (prices[i.id] || 0) * i.qty, 0);

  return (
    <div>
      <div className="bank-header">
        <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 4 }}>Total Bank Value</div>
        <div className="bank-total">{fmt(total)} gp</div>
        <div style={{ fontSize: 11, color: priceStatus === "live" ? "#4caf50" : "var(--muted)", marginTop: 4 }}>
          {priceStatus === "live" ? "✔ Live GE prices (RS Wiki)" : priceStatus === "loading" ? "Fetching prices…" : "Offline — prices unavailable"}
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div className="section-title" style={{ marginTop: 0 }}>Items</div>
        <button className="btn" onClick={() => setAdding(v => !v)} style={{ marginBottom: 8 }}>
          {adding ? "✕ Cancel" : "+ Add Item"}
        </button>
      </div>

      {adding && (
        <div style={{ background: "var(--parch2)", border: "1px solid var(--gold)", borderRadius: "var(--radius)", padding: 14, marginBottom: 12, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "flex-end" }}>
          <div><label className="input-label">Item Name</label><input className="splash-input" style={{ width: 160, marginBottom: 0 }} placeholder="e.g. Shark" value={newName} onChange={e => setNewName(e.target.value)} /></div>
          <div><label className="input-label">Qty</label><input className="splash-input" style={{ width: 80, marginBottom: 0 }} type="number" min="1" value={newQty} onChange={e => setNewQty(parseInt(e.target.value) || 1)} /></div>
          <div><label className="input-label">Item ID (from wiki)</label><input className="splash-input" style={{ width: 100, marginBottom: 0 }} placeholder="e.g. 385" value={newId} onChange={e => setNewId(e.target.value)} /></div>
          <button className="send-btn" onClick={() => { if (newName && newId) { addItem({ name: newName, qty: newQty, id: parseInt(newId) }); setAdding(false); setNewName(""); setNewQty(1); setNewId(""); } }}>Add</button>
        </div>
      )}

      <div className="bank-grid">
        {items.map(item => {
          const p = prices[item.id] || 0;
          return (
            <div className="bank-item" key={item.id} style={{ position: "relative" }}>
              <button onClick={() => removeItem(item.id)} style={{ position: "absolute", top: 6, right: 6, background: "none", border: "none", color: "var(--muted)", cursor: "pointer", fontSize: 12, lineHeight: 1 }}>✕</button>
              <div className="bank-item-name" style={{ paddingRight: 16 }}>{item.name}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 4, margin: "4px 0" }}>
                <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ background: "var(--parch2)", border: "1px solid var(--border)", color: "var(--gold)", borderRadius: 4, width: 20, height: 20, cursor: "pointer", fontSize: 14, lineHeight: 1 }}>−</button>
                <input
                  type="number"
                  min="1"
                  value={item.qty}
                  onChange={e => { const v = parseInt(e.target.value); if (!isNaN(v) && v > 0) updateQty(item.id, v); }}
                  onBlur={e => { if (!e.target.value || parseInt(e.target.value) < 1) updateQty(item.id, 1); }}
                  style={{ width: 56, background: "var(--parch2)", border: "1px solid var(--border)", borderRadius: 4, color: "var(--text)", fontSize: 12, textAlign: "center", padding: "2px 4px", fontFamily: "'Inter', sans-serif", MozAppearance: "textfield" }}
                />
                <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ background: "var(--parch2)", border: "1px solid var(--border)", color: "var(--gold)", borderRadius: 4, width: 20, height: 20, cursor: "pointer", fontSize: 14, lineHeight: 1 }}>+</button>
              </div>
              <div className="bank-item-val">{fmt(p * item.qty)} gp</div>
              <div className="bank-item-ea">{p > 0 ? `${p.toLocaleString()} ea` : "Price unknown"}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// FEATURE 5 — POLISH: Loading skeleton + mobile tweaks
// ─────────────────────────────────────────────
const skeletonStyles = `
  input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
  input[type=number] { -moz-appearance: textfield; }
  @keyframes shimmer { 0%{background-position:-400px 0} 100%{background-position:400px 0} }
  .skeleton { background: linear-gradient(90deg, #2a1f0e 25%, #3a2a12 50%, #2a1f0e 75%); background-size: 400px 100%; animation: shimmer 1.4s infinite; border-radius: 4px; }
  @media (max-width: 480px) {
    .skills-grid { grid-template-columns: repeat(3, 1fr) !important; }
    .bank-grid   { grid-template-columns: repeat(2, 1fr) !important; }
    .header-stats { gap: 8px !important; }
    .stat-chip .val { font-size: 15px !important; }
    .content { padding: 10px !important; }
    .msg { max-width: 95% !important; }
  }
`;

function SkeletonSkills() {
  return (
    <div>
      <div className="skeleton" style={{ height: 16, width: 160, marginBottom: 12, marginTop: 20 }} />
      <div className="skills-grid">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="skill-card">
            <div className="skeleton" style={{ height: 12, width: "60%", marginBottom: 8 }} />
            <div className="skeleton" style={{ height: 28, width: "40%", marginBottom: 6 }} />
            <div className="skeleton" style={{ height: 4, width: "100%" }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Styles (inline for self-contained artifact) ──
const styles = skeletonStyles + `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1a1209; }
  :root {
    --parch: #2a1f0e;
    --parch2: #321e08;
    --gold: #c8a84b;
    --gold2: #f0d060;
    --red: #8b1a1a;
    --green: #2d6a2d;
    --text: #e8d5a3;
    --muted: #9a8060;
    --border: #4a3520;
    --radius: 8px;
  }
  .tracker { min-height: 100vh; background: #1a1209; color: var(--text); font-family: 'Inter', sans-serif; }
  .header { background: linear-gradient(135deg, #1a0f05 0%, #2a1a08 100%); border-bottom: 2px solid var(--gold); padding: 16px 20px; }
  .header-top { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; }
  .player-info h1 { font-family: 'Cinzel', serif; font-size: 22px; color: var(--gold2); letter-spacing: 1px; }
  .player-meta { font-size: 12px; color: var(--muted); margin-top: 2px; }
  .header-stats { display: flex; gap: 16px; flex-wrap: wrap; }
  .stat-chip { background: rgba(200,168,75,0.1); border: 1px solid var(--border); border-radius: 6px; padding: 8px 14px; text-align: center; }
  .stat-chip .val { font-family: 'Cinzel', serif; font-size: 18px; color: var(--gold2); font-weight: 700; }
  .stat-chip .lbl { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; }
  .sync-row { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 12px; color: var(--muted); }
  .dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .dot.live { background: #4caf50; box-shadow: 0 0 6px #4caf50; }
  .dot.cache { background: #ffc107; }
  .dot.offline { background: #f44336; }
  .btn { background: rgba(200,168,75,0.15); border: 1px solid var(--gold); color: var(--gold); padding: 5px 12px; border-radius: 5px; cursor: pointer; font-size: 12px; font-family: 'Inter', sans-serif; transition: all 0.2s; }
  .btn:hover { background: rgba(200,168,75,0.3); }
  .nav { display: flex; gap: 2px; background: #110a02; border-bottom: 1px solid var(--border); padding: 0 12px; overflow-x: auto; }
  .nav-btn { padding: 10px 16px; font-size: 13px; color: var(--muted); background: none; border: none; border-bottom: 2px solid transparent; cursor: pointer; font-family: 'Inter', sans-serif; white-space: nowrap; transition: all 0.15s; }
  .nav-btn.active { color: var(--gold2); border-bottom-color: var(--gold); }
  .nav-btn:hover:not(.active) { color: var(--text); }
  .content { padding: 16px; max-width: 900px; margin: 0 auto; }
  .section-title { font-family: 'Cinzel', serif; font-size: 14px; color: var(--gold); letter-spacing: 1px; margin: 20px 0 10px; text-transform: uppercase; border-bottom: 1px solid var(--border); padding-bottom: 6px; }
  .skills-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 8px; }
  .skill-card { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 10px; }
  .skill-header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
  .skill-icon { font-size: 14px; }
  .skill-name { font-size: 11px; color: var(--muted); }
  .skill-level { font-family: 'Cinzel', serif; font-size: 20px; color: var(--gold2); font-weight: 700; }
  .xp-bar { height: 4px; background: #111; border-radius: 2px; overflow: hidden; margin-top: 4px; }
  .xp-fill { height: 100%; background: linear-gradient(90deg, var(--gold), var(--gold2)); border-radius: 2px; transition: width 0.4s; }
  .xp-text { font-size: 9px; color: var(--muted); margin-top: 2px; }
  .advice-card { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; margin-bottom: 10px; }
  .advice-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
  .priority-badge { font-size: 10px; padding: 2px 8px; border-radius: 10px; font-weight: 600; }
  .priority-badge.high { background: #8b1a1a33; color: #ff6b6b; border: 1px solid #8b1a1a; }
  .priority-badge.strong { background: #1a6b1a33; color: #6bff6b; border: 1px solid #1a6b1a; }
  .priority-badge.note { background: #4a4a1a33; color: #ffff6b; border: 1px solid #4a4a1a; }
  .advice-title { font-family: 'Cinzel', serif; font-size: 13px; color: var(--gold); }
  .advice-body { font-size: 13px; color: var(--text); line-height: 1.6; }
  .milestone-card { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 12px 14px; margin-bottom: 8px; }
  .milestone-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
  .milestone-name { font-size: 13px; color: var(--text); font-weight: 500; }
  .milestone-pct { font-family: 'Cinzel', serif; font-size: 14px; color: var(--gold2); }
  .milestone-label { font-size: 11px; color: var(--muted); margin-bottom: 8px; }
  .goal-bar { height: 6px; background: #111; border-radius: 3px; overflow: hidden; }
  .goal-fill { height: 100%; border-radius: 3px; transition: width 0.5s; }
  .boss-card { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 12px 14px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
  .boss-info h3 { font-size: 13px; color: var(--text); margin-bottom: 3px; }
  .boss-info p { font-size: 11px; color: var(--muted); }
  .boss-status { font-size: 12px; font-weight: 600; white-space: nowrap; }
  .status-ready { color: #4caf50; }
  .status-close { color: #ffc107; }
  .status-locked { color: #f44336; }
  .quest-card { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 12px 14px; margin-bottom: 8px; }
  .quest-header { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 6px; }
  .quest-name { font-family: 'Cinzel', serif; font-size: 13px; color: var(--gold); }
  .quest-cat { font-size: 10px; color: var(--muted); margin-top: 2px; }
  .quest-badge { font-size: 11px; font-weight: 600; white-space: nowrap; }
  .quest-reqs { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }
  .req-pill { font-size: 10px; padding: 2px 8px; border-radius: 10px; }
  .req-met { background: #1a4a1a; color: #6bff6b; border: 1px solid #2d6a2d; }
  .req-unmet { background: #4a1a1a; color: #ff6b6b; border: 1px solid #8b1a1a; }
  .bank-header { background: var(--parch2); border: 1px solid var(--border); border-radius: var(--radius); padding: 14px; margin-bottom: 14px; text-align: center; }
  .bank-total { font-family: 'Cinzel', serif; font-size: 28px; color: var(--gold2); }
  .bank-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 8px; }
  .bank-item { background: var(--parch); border: 1px solid var(--border); border-radius: var(--radius); padding: 10px 12px; }
  .bank-item-name { font-size: 12px; color: var(--text); margin-bottom: 4px; }
  .bank-item-qty { font-size: 11px; color: var(--muted); }
  .bank-item-val { font-size: 13px; color: var(--gold2); font-weight: 600; margin-top: 4px; }
  .bank-item-ea { font-size: 10px; color: var(--muted); }
  .chat-container { display: flex; flex-direction: column; height: calc(100vh - 220px); min-height: 400px; }
  .suggestions { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
  .suggestion-chip { background: rgba(200,168,75,0.1); border: 1px solid var(--border); border-radius: 14px; padding: 5px 12px; font-size: 11px; color: var(--gold); cursor: pointer; transition: all 0.2s; }
  .suggestion-chip:hover { background: rgba(200,168,75,0.25); border-color: var(--gold); }
  .messages { flex: 1; overflow-y: auto; padding: 8px 0; display: flex; flex-direction: column; gap: 10px; }
  .msg { max-width: 85%; padding: 10px 14px; border-radius: 12px; font-size: 13px; line-height: 1.6; }
  .msg.user { background: rgba(200,168,75,0.15); border: 1px solid var(--border); margin-left: auto; color: var(--text); border-radius: 12px 12px 2px 12px; }
  .msg.ai { background: var(--parch2); border: 1px solid var(--border); margin-right: auto; color: var(--text); border-radius: 12px 12px 12px 2px; }
  .msg.ai.thinking { opacity: 0.6; font-style: italic; }
  .chat-input-row { display: flex; gap: 8px; margin-top: 10px; }
  .chat-input { flex: 1; background: var(--parch2); border: 1px solid var(--border); border-radius: 8px; padding: 10px 14px; color: var(--text); font-size: 13px; font-family: 'Inter', sans-serif; outline: none; }
  .chat-input:focus { border-color: var(--gold); }
  .send-btn { background: var(--gold); color: #1a1209; border: none; border-radius: 8px; padding: 10px 18px; font-weight: 600; cursor: pointer; font-size: 13px; transition: opacity 0.2s; }
  .send-btn:hover { opacity: 0.85; }
  .filter-row { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; }
  .filter-btn { background: var(--parch); border: 1px solid var(--border); border-radius: 14px; padding: 4px 12px; font-size: 11px; color: var(--muted); cursor: pointer; transition: all 0.15s; }
  .filter-btn.active { border-color: var(--gold); color: var(--gold); background: rgba(200,168,75,0.1); }
  .splash { min-height: 100vh; background: radial-gradient(ellipse at 50% 0%, #2a1500 0%, #0d0700 60%); display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; }
  .splash-card { background: rgba(30,15,5,0.92); border: 2px solid var(--gold); border-radius: 16px; padding: 36px 32px; max-width: 380px; width: 100%; text-align: center; backdrop-filter: blur(10px); }
  .splash-title { font-family: 'Cinzel', serif; font-size: 26px; color: var(--gold2); margin-bottom: 6px; }
  .splash-sub { font-size: 13px; color: var(--muted); margin-bottom: 28px; }
  .splash-input { width: 100%; background: rgba(255,255,255,0.05); border: 1px solid var(--border); border-radius: 8px; padding: 11px 14px; color: var(--text); font-size: 14px; font-family: 'Inter', sans-serif; outline: none; margin-bottom: 10px; }
  .splash-input:focus { border-color: var(--gold); }
  .splash-select { width: 100%; background: rgba(20,10,2,0.9); border: 1px solid var(--border); border-radius: 8px; padding: 10px 14px; color: var(--text); font-size: 13px; font-family: 'Inter', sans-serif; outline: none; margin-bottom: 18px; }
  .splash-btn { width: 100%; background: var(--gold); color: #1a1209; border: none; border-radius: 8px; padding: 13px; font-family: 'Cinzel', serif; font-size: 15px; font-weight: 700; cursor: pointer; letter-spacing: 1px; transition: opacity 0.2s; }
  .splash-btn:hover { opacity: 0.88; }
  .splash-error { color: #ff6b6b; font-size: 12px; margin-top: 8px; }
  .lb-bg { position: fixed; top: 0; left: 0; right: 0; bottom: 0; overflow: hidden; pointer-events: none; z-index: 0; display: flex; flex-direction: column; justify-content: space-evenly; }
  .lb-row { font-size: 11px; color: rgba(200,168,75,0.18); font-family: 'Cinzel', serif; padding: 3px 20px; animation: fadein 0.5s ease forwards; opacity: 0; }
  @keyframes fadein { to { opacity: 1; } }
  .input-group { margin-bottom: 12px; }
  .input-label { font-size: 11px; color: var(--muted); margin-bottom: 4px; display: block; }
  .api-key-notice { font-size: 11px; color: #ffc107; background: rgba(255,193,7,0.08); border: 1px solid rgba(255,193,7,0.25); border-radius: 6px; padding: 8px 10px; margin-bottom: 12px; text-align: left; }
`;

// ── Helpers ──
// Fix #4: guard all three base stats against undefined
function calcCombat(s) {
  const base = 0.25 * (
    (s.Defence?.level || 1) +
    (s.Hitpoints?.level || 10) +
    Math.floor((s.Prayer?.level || 1) / 2)
  );
  const melee  = 0.325 * ((s.Attack?.level  || 1) + (s.Strength?.level || 1));
  const ranged = 0.325 * Math.floor((s.Ranged?.level || 1) * 1.5);
  const magic  = 0.325 * Math.floor((s.Magic?.level  || 1) * 1.5);
  return Math.floor(base + Math.max(melee, ranged, magic));
}

function bossReady(boss, skills) {
  return Object.entries(boss.reqs).every(([sk, lvl]) => (skills[sk]?.level || 1) >= lvl);
}

function questStatus(quest, skills) {
  const unmet = Object.entries(quest.reqs).filter(([sk, lvl]) => (skills[sk]?.level || 1) < lvl);
  if (unmet.length === 0) return "ready";
  const closeEnough = unmet.every(([sk, lvl]) => (skills[sk]?.level || 1) >= lvl - 5);
  return closeEnough ? "close" : "locked";
}

// ── Splash Screen ──
function Splash({ onEnter }) {
  const [username, setUsername] = useState("");
  const [type, setType] = useState("normal");
  const [apiKey, setApiKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function handleEnter() {
    if (!username.trim()) { setErr("Enter a username."); return; }
    setLoading(true); setErr("");
    try {
      const saved = { username: username.trim(), type };
      localStorage.setItem("osrs_account", JSON.stringify(saved));
      // Fix #6: store API key in sessionStorage only (not localStorage), never log it
      if (apiKey.trim()) sessionStorage.setItem("osrs_api_key", apiKey.trim());
      onEnter(saved);
    } catch { setErr("Could not save. Try again."); }
    setLoading(false);
  }

  return (
    <div className="splash">
      <style>{styles}</style>
      {/* Fix #9: lb-bg uses flex column with space-evenly so all rows are spread vertically */}
      <div className="lb-bg">
        {LB_ROWS.map((r, i) => (
          <div key={i} className="lb-row" style={{ animationDelay: `${i * 0.12}s` }}>
            {i + 1}. {r}
          </div>
        ))}
      </div>
      <div className="splash-card" style={{ position: "relative", zIndex: 1 }}>
        <div style={{ fontSize: 36, marginBottom: 8 }}>⚔️</div>
        <div className="splash-title">OSRSBuddy</div>
        <div className="splash-sub">Enter your account to load your stats, advice, quest readiness, and more.</div>
        <div className="input-group">
          <label className="input-label">RuneScape Username</label>
          <input className="splash-input" placeholder="e.g. Legaet-Plix" value={username}
            onChange={e => setUsername(e.target.value)} onKeyDown={e => e.key === "Enter" && handleEnter()} />
        </div>
        <div className="input-group">
          <label className="input-label">Account Type</label>
          <select className="splash-select" value={type} onChange={e => setType(e.target.value)}>
            <option value="normal">Normal</option>
            <option value="ironman">Ironman</option>
            <option value="hcim">Hardcore Ironman</option>
            <option value="uim">Ultimate Ironman</option>
          </select>
        </div>
        {/* Fix #6: API key collected at runtime, stored in sessionStorage only */}
        <div className="input-group">
          <label className="input-label">Anthropic API Key (for Chat tab)</label>
          <div className="api-key-notice">
            ⚠️ Your key is stored in <strong>sessionStorage</strong> only and cleared when you close the tab. Never share or commit it.
          </div>
          <input className="splash-input" type="password" placeholder="sk-ant-…" value={apiKey}
            onChange={e => setApiKey(e.target.value)} />
        </div>
        <button className="splash-btn" onClick={handleEnter} disabled={loading}>
          {loading ? "Loading…" : "Enter Tracker →"}
        </button>
        {err && <div className="splash-error">{err}</div>}
      </div>
    </div>
  );
}

// ── Skills Tab ──
// Fix #12: Overall shown as a summary banner row, not duplicated in skill groups
function SkillsTab({ skills }) {
  const groups = [
    { label: "Combat Skills",        names: ["Attack","Strength","Defence","Hitpoints","Ranged","Prayer","Magic","Slayer"] },
    { label: "Support Skills",       names: ["Cooking","Fishing","Firemaking","Crafting","Smithing","Agility","Thieving","Herblore"] },
    { label: "Gathering & Artisan",  names: ["Mining","Woodcutting","Fletching","Farming","Runecrafting","Hunter","Construction"] },
  ];
  const overall = skills["Overall"];
  return (
    <div>
      {overall && (
        <div style={{ background: "var(--parch2)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "10px 14px", marginBottom: 4, display: "flex", alignItems: "center", gap: 16 }}>
          <span style={{ fontFamily: "'Cinzel', serif", fontSize: 13, color: "var(--gold)" }}>Overall</span>
          <span style={{ fontFamily: "'Cinzel', serif", fontSize: 20, color: "var(--gold2)", fontWeight: 700 }}>{overall.level}</span>
          <span style={{ fontSize: 11, color: "var(--muted)" }}>{fmt(overall.xp)} total xp</span>
        </div>
      )}
      {groups.map(g => (
        <div key={g.label}>
          <div className="section-title">{g.label}</div>
          <div className="skills-grid">
            {g.names.map(name => {
              const s = skills[name] || { level: 1, xp: 0 };
              const pct = xpProgress(s.xp);
              const sk = SKILLS.find(x => x.name === name);
              return (
                <div className="skill-card" key={name}>
                  <div className="skill-header">
                    <span className="skill-icon">{sk?.icon}</span>
                    <span className="skill-name">{name}</span>
                  </div>
                  <div className="skill-level">{s.level}</div>
                  <div className="xp-bar"><div className="xp-fill" style={{ width: `${pct * 100}%` }} /></div>
                  <div className="xp-text">{fmt(s.xp)} xp</div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Advice Tab ──
function AdviceTab({ skills }) {
  const items = [
    { condition: (skills.Ranged?.level || 1) < 30, priority: "high", title: "⚔️ Train Ranged — it's level " + (skills.Ranged?.level || 1), body: "Ranged is essential for quests, bosses, and slayer. Start with Temple of Ikov or just train at sand crabs. Get to 70 for Blowpipe and mid-game bossing." },
    { condition: (skills.Prayer?.level || 1) < 43, priority: "high", title: "🙏 Prayer to 43 — Protect from Melee", body: "43 Prayer unlocks Protect from Melee, the most impactful PvM prayer. Use a Gilded Altar on W330 with dragon bones — ~20 bones to reach 43 from where you are now." },
    { condition: (skills.Magic?.level || 1) < 55, priority: "high", title: "🔮 Magic to 55 — High Alchemy", body: "Splash Air Strike overnight (use -65 magic gear) for free AFK XP to 55. At 55 you unlock High Alchemy — turn slayer drops into passive GP every run." },
    { condition: (skills.Agility?.level || 1) < 30, priority: "note", title: "🏃 Agility — start Gnome Stronghold", body: "Even 30 Agility makes a big difference to run energy. The Grand Tree quest gives 18,400 Agility XP — do it early. Gnome Stronghold is the best early rooftop course." },
    { condition: (skills.Crafting?.level || 1) >= 50, priority: "strong", title: "✂️ Crafting " + (skills.Crafting?.level || 1) + " — strong for your level", body: "Your Crafting is impressive for a 421 total account. 66 unlocks Lunar Diplomacy, 70 opens the Fury crafting method. Keep training." },
    { condition: (skills.Slayer?.level || 1) >= 30, priority: "strong", title: "💀 Slayer — keep grinding", body: "Slayer is your backbone for GP and combat XP simultaneously. Prioritise unlocking Bigger and Badder (Superiors) and the Slayer Helm as soon as you have enough points." },
  ].filter(i => i.condition);

  return (
    <div>
      <div className="section-title">Priority Advice</div>
      {items.length === 0 && <div style={{ color: "var(--muted)", fontSize: 13 }}>No urgent advice — looking solid!</div>}
      {items.map((a, i) => (
        <div className="advice-card" key={i}>
          <div className="advice-header">
            <span className={`priority-badge ${a.priority}`}>{a.priority === "high" ? "Priority" : a.priority === "strong" ? "Strong" : "Note"}</span>
            <span className="advice-title">{a.title}</span>
          </div>
          <div className="advice-body">{a.body}</div>
        </div>
      ))}
    </div>
  );
}

// ── Goals Tab ──
// Fix #3: use xpToLevel(currXp) as the canonical "done" check, consistent with the bar
function GoalsTab({ skills }) {
  return (
    <div>
      <div className="section-title">Suggested Milestones</div>
      {MILESTONES.map(m => {
        const currXp   = skills[m.skill]?.xp || 0;
        const targetXp = xpForLevel(m.target);
        const pct      = Math.min(1, currXp / targetXp);
        const done     = xpToLevel(currXp) >= m.target;
        return (
          <div className="milestone-card" key={m.skill}>
            <div className="milestone-header">
              <div>
                <div className="milestone-name">{m.skill} → {m.target}</div>
                <div className="milestone-label">{m.label}</div>
              </div>
              <div className="milestone-pct">{done ? "✓" : Math.round(pct * 100) + "%"}</div>
            </div>
            <div className="goal-bar">
              <div className="goal-fill" style={{ width: `${pct * 100}%`, background: done ? "#4caf50" : m.color }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Quests Tab ──
function QuestsTab({ skills }) {
  const [filter, setFilter] = useState("all");
  const filters = ["all", "ready", "close", "locked"];

  const filtered = QUESTS_FULL.filter(q => {
    const s = questStatus(q, skills);
    if (filter === "all") return true;
    return filter === s;
  });

  return (
    <div>
      <div className="section-title">Quest Tracker</div>
      <div className="filter-row">
        {filters.map(f => (
          <button key={f} className={`filter-btn ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
            {f === "all" ? "All" : f === "ready" ? "✅ Ready" : f === "close" ? "⚡ Close" : "🔒 Locked"}
          </button>
        ))}
      </div>
      {filtered.map(q => {
        const s = questStatus(q, skills);
        return (
          <div className="quest-card" key={q.name}>
            <div className="quest-header">
              <div>
                <div className="quest-name">{q.name}</div>
                <div className="quest-cat">{q.category}</div>
              </div>
              <div className={`quest-badge ${s === "ready" ? "status-ready" : s === "close" ? "status-close" : "status-locked"}`}>
                {s === "ready" ? "✔ Ready now" : s === "close" ? "⚡ Almost" : "✖ Locked"}
              </div>
            </div>
            <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 4 }}>{q.desc}</div>
            <div style={{ fontSize: 11, color: "var(--gold)", marginBottom: 6 }}>Reward: {q.reward}</div>
            <div className="quest-reqs">
              {Object.entries(q.reqs).map(([sk, lvl]) => {
                const met = (skills[sk]?.level || 1) >= lvl;
                return <span key={sk} className={`req-pill ${met ? "req-met" : "req-unmet"}`}>{sk} {lvl} ({skills[sk]?.level || 1}/{lvl})</span>;
              })}
              {Object.keys(q.reqs).length === 0 && <span className="req-pill req-met">No skill reqs</span>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── PvM Tab ──
function PvMTab({ skills }) {
  return (
    <div>
      <div className="section-title">Boss Readiness</div>
      <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 12 }}>
        At combat level {calcCombat(skills)} with melee-focused stats, here's where you stand:
      </div>
      {BOSSES_FULL.map(b => {
        const ready = bossReady(b, skills);
        const unmet = Object.entries(b.reqs).filter(([sk, lvl]) => (skills[sk]?.level || 1) < lvl);
        const close = !ready && unmet.every(([sk, lvl]) => (skills[sk]?.level || 1) >= lvl - 10);
        return (
          <div className="boss-card" key={b.name}>
            <div className="boss-info">
              <h3>{b.name}</h3>
              <p>{b.desc}</p>
              {!ready && unmet.map(([sk, lvl]) => (
                <span key={sk} style={{ fontSize: 10, color: "#ff6b6b" }}>Need {sk} {lvl} (you: {skills[sk]?.level || 1}) </span>
              ))}
            </div>
            <div className={`boss-status ${ready ? "status-ready" : close ? "status-close" : "status-locked"}`}>
              {ready ? "✔ Ready" : close ? "⚡ Close" : "✖ Not yet"}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Bank Tab ──
// Fix #11: fetch live GE prices from the RS Wiki API (CORS-open, no auth)
function BankTab({ skills }) {
  const ids = BANK_ITEMS.map(i => i.id);
  const [prices, setPrices] = useState({ 1333: 15000, 536: 2942, 1127: 38000, 561: 200, 385: 850, 2434: 9500, 207: 7800, 1123: 3200, 1513: 680, 453: 210, 444: 280, 1515: 560 });
  const [priceStatus, setPriceStatus] = useState("static");

  useEffect(() => {
    async function fetchPrices() {
      try {
        const res = await fetch(
          `https://prices.runescape.wiki/api/v1/latest?id=${ids.join(",")}`,
          { headers: { "User-Agent": "OSRSBuddy tracker app" } }
        );
        if (!res.ok) return;
        const json = await res.json();
        const live = {};
        for (const [id, data] of Object.entries(json.data || {})) {
          // Use mid-price between high and low
          const high = data.high || 0;
          const low  = data.low  || 0;
          live[parseInt(id)] = high && low ? Math.round((high + low) / 2) : (high || low);
        }
        if (Object.keys(live).length > 0) {
          setPrices(prev => ({ ...prev, ...live }));
          setPriceStatus("live");
        }
      } catch {
        // silently keep static fallback prices
      }
    }
    fetchPrices();
  }, []);

  const total = BANK_ITEMS.reduce((s, i) => s + (prices[i.id] || 0) * i.qty, 0);
  return (
    <div>
      <div className="bank-header">
        <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 4 }}>Total Bank Value</div>
        <div className="bank-total">{fmt(total)} gp</div>
        <div style={{ fontSize: 11, color: priceStatus === "live" ? "#4caf50" : "var(--muted)", marginTop: 4 }}>
          {priceStatus === "live" ? "✔ Live GE prices (RS Wiki)" : "Static fallback prices"}
        </div>
      </div>
      <div className="section-title">Items</div>
      <div className="bank-grid">
        {BANK_ITEMS.map(item => {
          const p = prices[item.id] || 0;
          const val = p * item.qty;
          return (
            <div className="bank-item" key={item.id}>
              <div className="bank-item-name">{item.name}</div>
              <div className="bank-item-qty">× {item.qty.toLocaleString()}</div>
              <div className="bank-item-val">{fmt(val)} gp</div>
              <div className="bank-item-ea">{p.toLocaleString()} ea</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Chat Tab ──
// Fix #1: add required CORS + auth headers for direct browser Anthropic calls
// Fix #6: API key read from sessionStorage at call time (never hardcoded)
// Fix #8: strip the initial greeting from history so first message is always role:user
function ChatTab({ skills, username }) {
  const GREETING = `Hey! I'm your OSRS advisor for ${username}. Ask me anything — skill training, quests, bosses, XP calculations, or just what to do next.`;
  const [messages, setMessages] = useState([{ role: "ai", text: GREETING }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  const suggestions = [
    "What should I do first?",
    "How many bones to Prayer 43?",
    "Can I do Barrows yet?",
    "Best way to train Ranged?",
    "What quests should I do?",
    "How do I get to 55 Magic?",
  ];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const statsStr = Object.entries(skills)
    .filter(([k]) => k !== "Overall")
    .map(([k, v]) => `${k}: ${v.level} (${fmt(v.xp)} xp)`)
    .join(", ");

  async function send(text) {
    const userMsg = text || input.trim();
    if (!userMsg) return;
    setInput("");
    const newMsgs = [...messages, { role: "user", text: userMsg }];
    setMessages([...newMsgs, { role: "ai", text: "Thinking…", thinking: true }]);
    setLoading(true);

    const apiKey = sessionStorage.getItem("osrs_api_key") || "";
    if (!apiKey) {
      setMessages([...newMsgs, { role: "ai", text: "No API key found. Please restart and enter your Anthropic API key on the login screen." }]);
      setLoading(false);
      return;
    }

    const systemPrompt = `You are an expert Old School RuneScape (OSRS) advisor. The player's username is ${username}.
Their current stats: ${statsStr}
Combat level: ${calcCombat(skills)}

Give practical, specific OSRS advice based on THEIR actual stats. Be concise but helpful. Reference their actual levels when relevant. Use OSRS terminology naturally. If they ask about XP needed, calculate it from their current XP. Always suggest the most efficient next step.`;

    // Fix #8: skip the greeting (index 0) so the API history always starts with role:user
    const history = newMsgs
      .slice(1)
      .map(m => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // Fix #1: required headers for direct browser access
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-5",
          max_tokens: 1000,
          system: systemPrompt,
          messages: history,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const reply = data.content?.map(c => c.text).join("") || "Sorry, I couldn't get a response.";
      setMessages([...newMsgs, { role: "ai", text: reply }]);
    } catch (e) {
      setMessages([...newMsgs, { role: "ai", text: `Error: ${e.message || "Connection failed — check your API key and network."}` }]);
    }
    setLoading(false);
  }

  return (
    <div className="chat-container">
      <div className="suggestions">
        {suggestions.map(s => (
          <button key={s} className="suggestion-chip" onClick={() => send(s)}>{s}</button>
        ))}
      </div>
      <div className="messages">
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role} ${m.thinking ? "thinking" : ""}`}>{m.text}</div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="chat-input-row">
        <input className="chat-input" placeholder="Ask anything about your account…" value={input}
          onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && !loading && send()} />
        <button className="send-btn" onClick={() => send()} disabled={loading}>Send</button>
      </div>
    </div>
  );
}

// ── Main App ──
export default function OSRSTracker() {
  const [account, setAccount] = useState(null);
  const [skills, setSkills] = useState(SNAPSHOT.skills);
  const [tab, setTab] = useState("Skills");
  const { gains, resetBaseline } = useXpTracker(skills);
  const [syncStatus, setSyncStatus] = useState("offline");
  const [lastSync, setLastSync] = useState(null);
  const tabs = ["Skills", "Gains", "Advice", "Goals", "Quests", "PvM", "Bank", "Chat"];

  useEffect(() => {
    const saved = localStorage.getItem("osrs_account");
    if (saved) {
      try { setAccount(JSON.parse(saved)); } catch {}
    }
  }, []);

  // Fix #7: use Wise Old Man API — proper CORS, no third-party proxy, structured JSON
  // Fix #5: sanity-check that Attack level > 1 or Overall xp > 0 before accepting data
  const fetchStats = useCallback(async (uname) => {
    try {
      const res = await fetch(
        `https://api.wiseoldman.net/v2/players/${encodeURIComponent(uname)}`,
        { signal: AbortSignal.timeout(8000) }
      );
      if (!res.ok) throw new Error("WOM fetch failed");
      const data = await res.json();
      const latestSnapshot = data.latestSnapshot?.data?.skills;
      if (!latestSnapshot) throw new Error("No snapshot data");

      const skillMap = {
        Overall: "overall", Attack: "attack", Defence: "defence", Strength: "strength",
        Hitpoints: "hitpoints", Ranged: "ranged", Prayer: "prayer", Magic: "magic",
        Cooking: "cooking", Woodcutting: "woodcutting", Fletching: "fletching",
        Fishing: "fishing", Firemaking: "firemaking", Crafting: "crafting",
        Smithing: "smithing", Mining: "mining", Herblore: "herblore", Agility: "agility",
        Thieving: "thieving", Slayer: "slayer", Farming: "farming",
        Runecrafting: "runecrafting", Hunter: "hunter", Construction: "construction",
      };
      const newSkills = {};
      for (const [displayName, womKey] of Object.entries(skillMap)) {
        const entry = latestSnapshot[womKey];
        newSkills[displayName] = { level: entry?.level || 1, xp: entry?.experience || 0 };
      }

      // Fix #5: sanity check before accepting
      if ((newSkills.Attack?.level || 1) <= 1 && (newSkills.Overall?.xp || 0) === 0) {
        throw new Error("Suspicious data — all stats are level 1");
      }

      setSkills(newSkills);
      setSyncStatus("live");
      setLastSync(new Date());
      localStorage.setItem("osrs_cache", JSON.stringify({ skills: newSkills, t: Date.now() }));
    } catch {
      // Try local cache before falling back to SNAPSHOT
      const cached = localStorage.getItem("osrs_cache");
      if (cached) {
        try {
          const c = JSON.parse(cached);
          setSkills(c.skills);
          setSyncStatus("cache");
          setLastSync(new Date(c.t));
          return;
        } catch {}
      }
      setSyncStatus("offline");
    }
  }, []);

  useEffect(() => {
    if (account) {
      fetchStats(account.username);
      const iv = setInterval(() => fetchStats(account.username), 600000);
      return () => clearInterval(iv);
    }
  }, [account, fetchStats]);

  if (!account) return <Splash onEnter={a => { setAccount(a); fetchStats(a.username); }} />;

  const combat   = calcCombat(skills);
  const totalLvl = Object.entries(skills).filter(([k]) => k !== "Overall").reduce((s, [, v]) => s + (v.level || 1), 0);

  return (
    <div className="tracker">
      <style>{styles}</style>
      <div className="header">
        <div className="header-top">
          <div className="player-info">
            <h1>⚔️ OSRSBuddy — {account.username}</h1>
            <div className="player-meta">{account.type === "normal" ? "Regular" : account.type.toUpperCase()} · OSRS</div>
          </div>
          <div className="header-stats">
            <div className="stat-chip"><div className="val">{combat}</div><div className="lbl">Combat</div></div>
            <div className="stat-chip"><div className="val">{totalLvl}</div><div className="lbl">Total Lvl</div></div>
            <div className="stat-chip"><div className="val">{fmt(skills.Overall?.xp || 0)}</div><div className="lbl">Total XP</div></div>
          </div>
        </div>
        <div className="sync-row">
          <div className={`dot ${syncStatus}`} />
          <span>{syncStatus === "live" ? "Live" : syncStatus === "cache" ? "Cached" : "Offline"}</span>
          {lastSync && <span>· {lastSync.toLocaleTimeString()}</span>}
          <button className="btn" onClick={() => fetchStats(account.username)}>↻ Refresh</button>
          <button className="btn" onClick={() => { localStorage.removeItem("osrs_account"); setAccount(null); }}>⚙ Switch</button>
        </div>
      </div>
      <nav className="nav">
        {tabs.map(t => <button key={t} className={`nav-btn ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>{t}</button>)}
      </nav>
      <div className="content">
        {tab === "Skills"  && (syncStatus === "offline" && Object.values(skills).every(s => s.xp === 0) ? <SkeletonSkills /> : <SkillsTab skills={skills} />)}
        {tab === "Gains"   && <XpTrackerTab skills={skills} gains={gains} resetBaseline={resetBaseline} />}
        {tab === "Advice"  && <AdviceTab skills={skills} />}
        {tab === "Goals"   && <GoalsTab  skills={skills} />}
        {tab === "Quests"  && <QuestsTab skills={skills} />}
        {tab === "PvM"     && <PvMTab    skills={skills} />}
        {tab === "Bank"    && <BankTabV2 />}
        {tab === "Chat"    && <ChatTab   skills={skills} username={account.username} />}
      </div>
    </div>
  );
}
