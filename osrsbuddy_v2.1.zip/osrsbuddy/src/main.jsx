import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import OSRSTracker from "./OSRSTracker.jsx";
createRoot(document.getElementById("root")).render(<StrictMode><OSRSTracker /></StrictMode>);